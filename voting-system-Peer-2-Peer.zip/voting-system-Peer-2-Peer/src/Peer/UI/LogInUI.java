package Peer.UI;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;

public class LogInUI extends GridPane {
    private TextField privateKeyField;
    private PasswordField passwordField;
    private RadioButton adminRadioButton;
    private RadioButton userRadioButton;
    private ToggleGroup userTypeToggleGroup;
    @SuppressWarnings("unused")
    private Navigator navigator;
    @SuppressWarnings("unused")
    private Socket socket;
    private RadioButton selectedTypeRadioButton;
    private BufferedWriter bWriter;
    private BufferedReader bReader;
    private Text accessStatus;
    private static String tempKey=null;
    
    public LogInUI(Navigator navigator) {
        this.navigator = navigator;

        /**********************************Setting/initializing up Socket **************************/
        this.socket = navigator.getSocket();

        /**********************************Initializing the read and write fields***************** */
        try {
            bWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            bReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        setPrefSize(1250, 700);
        this.setVgap(10);
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);
        setAlignment(Pos.CENTER); // Center the content within the GridPane

        /******************* Label**********************/
        GridPane logGridPane = new GridPane();
        logGridPane.setAlignment(Pos.CENTER);
        Label logInLabel = new Label("LogIn");
        Label privateKeyLabel = new Label("Key:");
        Label passwordLabel = new Label("Password:");
        Label userTypeLabel = new Label("User Type:");
        logGridPane.add(logInLabel, 0, 0, 2, 1);
        logInLabel.setFont(Font.font(24)); // Set larger font size
        grid.add(privateKeyLabel, 0, 0);
        grid.add(passwordLabel, 0, 1);
        grid.add(userTypeLabel, 0, 2);
        this.add(logGridPane, 0, 0);

        /**************TextField/TextArea/passwordField***/
        privateKeyField = new TextField();
        passwordField = new PasswordField();
        accessStatus = new Text();
        grid.add(privateKeyField, 1, 0);
        grid.add(passwordField, 1, 1);

        /**************Radio Buttons**************/
        adminRadioButton = new RadioButton("Admin");
        userRadioButton = new RadioButton("User");
        userTypeToggleGroup = new ToggleGroup();
        adminRadioButton.setToggleGroup(userTypeToggleGroup);
        userRadioButton.setToggleGroup(userTypeToggleGroup);
        adminRadioButton.setSelected(true);
        selectedTypeRadioButton = adminRadioButton;
        adminRadioButton.setOnAction(e -> selectedTypeRadioButton = adminRadioButton);
        userRadioButton.setOnAction(e -> selectedTypeRadioButton = userRadioButton);
        grid.add(adminRadioButton, 1, 2);
        grid.add(userRadioButton, 1, 3);

        /**************Buttons**************/
        Button LogInButton = new Button("LogIn");
        Button backButton = new Button("Back");
        GridPane backPane = new GridPane();
        backPane.setAlignment(Pos.CENTER);
        backPane.getChildren().add(backButton);
        
        grid.add(LogInButton, 0, 5, 2, 1);
        this.add(grid, 0, 1);
        this.add(backPane,0,2);
        accessStatus.setText("Either password/key is incorrect");
        accessStatus.setFill(Color.RED);
        accessStatus.setFont(Font.font(14));
        accessStatus.setOpacity(0);
        grid.add(accessStatus, 0, 4); 
        
        showTemporaryPopup(navigator.getStage());

        LogInButton.setOnAction(e -> {
            // Gets the selected user type (Admin or User)
            String userType = selectedTypeRadioButton.getText();
            if(userType.isEmpty()||privateKeyField.getText().isEmpty()||passwordField.getText().isEmpty()){
                 // Show alert for empty fields
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Login Error");
                alert.setHeaderText(null);
                alert.setContentText("Please fill out all fields.");
                alert.showAndWait();
            }else{
                tempKey = privateKeyField.getText();
                // Sends the login request to the server
                boolean loginSuccessful = sendLogin(userType);
                // Handling the response from the server
                if (loginSuccessful&&userType.equals("User")) {
                    System.out.println("user Log in success");
                    Platform.runLater(() -> navigator.navigateToUserMenu()); // Navigate to user menu on the UI thread
                } else if (loginSuccessful && userType.equals("Admin")) {
                    System.out.println("admin Log in success");
                    Platform.runLater(() -> navigator.navigateToAdmin()); // Navigate to admin page on the UI thread
                }else {
                    accessStatus.setOpacity(1);
                }
            }
            
        });
        
        backButton.setOnAction(e -> {
            navigator.navigateToWelcome();
        });

        /******************styles*****************/
        WelcomeUI.styleButton(backButton);
        WelcomeUI.styleButton(LogInButton);
        this.setStyle(
                "-fx-background-image: url('Peer/imgs/whiteTallBuildings.jpg');" +
                        "-fx-background-size: cover;" +
                        "-fx-background-repeat: no-repeat;"
        );
        logInLabel.setTextFill(Color.rgb(41, 137, 216));
        grid.setStyle("-fx-border-color: #b3c3c7");
    }
    public static String getTempKey() {
        return tempKey;
    }

    private boolean sendLogin(String type){
        writeToServer("LogIn");
        writeToServer(type+"\'"+tempKey+"\'"+passwordField.getText());
        String response = readFromServer();
        String tempArr[] = response.split("\'");
        if(response.contains("true")){
            return true;
        }else if(response.contains("true") && tempArr.length==1){
            return true;
        }
        return false;
    }

    private String readFromServer(){
        String response=null;
        try{
            response = bReader.readLine();
        }catch(Exception e){
            e.printStackTrace();
        }
        return response;
    }

    private void writeToServer(String string){
        try{
            bWriter.write(string);
            bWriter.newLine();
            bWriter.flush();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private void showTemporaryPopup(Stage primaryStage) {
        // Create a new popup
        Popup popup = new Popup();

        // Create content for the popup
        Label popupLabel = new Label("Admin Login details:\nKey: admin\nPassword: 1234");
        popupLabel.setStyle("-fx-font-size: 18px;"+
                            "-fx-font-color: Orange;");

        // Create a StackPane to hold popup content
        StackPane popupPane = new StackPane(popupLabel);
        popupPane.setStyle("-fx-background-color: #f5f5f5;"); // Transparent overlay

        // Set the content of the popup
        popup.getContent().add(popupPane);

        // Position the popup relative to the primary stage
        double popupWidth = 200;
        double popupHeight = 100;
       
        popup.setX(600);
        popup.setY(90);

        // Set the size of the popup
        popup.setWidth(popupWidth);
        popup.setHeight(popupHeight);

        // Show the popup
        popup.show(primaryStage);

        // Set up a timeline to automatically hide the popup after a certain duration
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(6), event -> popup.hide()));
        timeline.play();
    }

}
