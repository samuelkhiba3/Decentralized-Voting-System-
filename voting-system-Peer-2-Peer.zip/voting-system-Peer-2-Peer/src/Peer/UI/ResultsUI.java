package Peer.UI;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class ResultsUI extends GridPane {

    private Navigator navigator;
    private Socket socket;
    private BufferedWriter bWriter;
    private BufferedReader bReader;
    private VBox vBox;

    public ResultsUI(Navigator navigator) {
        this.navigator = navigator;
        this.socket = navigator.getSocket();
        setPreferences();
        setupStreams();

        Label titleLabel = new Label("Election Results");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titleLabel.setAlignment(Pos.CENTER);
        writeToServer("Results");
        writeToServer("ready");
        String response = readFromServer();

        vBox = new VBox();
        vBox.setPrefSize(700,700);
        vBox.setSpacing(15);
        vBox.setStyle("-fx-background-color: linear-gradient(to bottom, #7795d1, #f5f4f2);");
        ScrollPane scrollPane = new ScrollPane(vBox);
        scrollPane.setFitToWidth(true);
        

        Text resultText = new Text();
        if (response.equals("ready")) {
            displayResults(resultText);
        }
        addComponents(titleLabel, scrollPane);
    }

    private void setPreferences() {
        setPrefSize(1250, 700);
        setVgap(10);
        setHgap(10);
        setAlignment(Pos.CENTER);
        setPadding(new Insets(10));
        setStyle("-fx-background-image: url('Peer/imgs/whiteTallBuildings.jpg');" +
                 "-fx-background-size: cover;" +
                 "-fx-background-repeat: no-repeat;");
    }

    private void setupStreams() {
        try {
            bWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            bReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void writeToServer(String string) {
        try {
            bWriter.write(string);
            bWriter.newLine();
            bWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String readFromServer() {
        String response = null;
        try {
            response = bReader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    private void displayResults(Text resultText) {
            String response = readFromServer();
            System.out.println(response);
            // Split the string by "'Candidate: " to separate each candidate's information
            String[] candidateInfos = response.split("'Candidate: ");
            
            // Process each candidate's information
            for (int i = 1; i < candidateInfos.length; i++) {
                String candidateInfo = candidateInfos[i];

                // Split the candidate's information by "'" to get individual fields
                String[] fields = candidateInfo.split("'");

                // Extract and store each field in the candidates array
                String name = fields[0].trim(); // Candidate name
                String age = fields[1].split(": ")[1].trim(); // Candidate age
                String gender = fields[2].split(": ")[1].trim(); // Candidate gender
                String ID = fields[3].split(": ")[1].trim(); // Candidate ID
                String votes = fields[4].split(": ")[1].trim(); // Candidate votes

                GridPane candidateGrid = new GridPane();
                candidateGrid.setPadding(new Insets(10));
                candidateGrid.setAlignment(Pos.TOP_CENTER);
                Label nameLabel = new Label("Name:");
                Label ageLabel = new Label("Age:");
                Label genderLabel = new Label("Gender:");
                Label iDLabel = new Label("ID:");
                Label votesLabel = new Label("Votes");

                TextField nameField = new TextField(name);
                TextField ageField = new TextField(age);
                TextField genderField = new TextField(gender);
                TextField iDField = new TextField(ID);
                TextField votesField = new TextField(votes);

                candidateGrid.add(nameLabel,0, 0);
                candidateGrid.add(nameField, 1, 0);
                candidateGrid.add(ageLabel, 0, 1);
                candidateGrid.add(ageField, 1, 1);
                candidateGrid.add(genderLabel, 0, 2);
                candidateGrid.add(genderField, 1, 2);
                candidateGrid.add(iDLabel, 0, 3);
                candidateGrid.add(iDField, 1, 3);
                candidateGrid.add(votesLabel, 0, 4);
                candidateGrid.add(votesField, 1, 4);

                vBox.getChildren().add(candidateGrid);
            }
    }

    private void addComponents(Label titleLabel, ScrollPane scrollPane) {
        add(titleLabel, 0, 0, 2, 1);
        add(scrollPane, 0, 1);

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> navigator.navigateToUserMenu());
        add(backButton, 0, 2);

        WelcomeUI.styleButton(backButton);
    }
}
