package Peer.UI;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.time.LocalDate;

import javafx.scene.control.DatePicker;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class AdminUI extends GridPane{
    private Navigator navigator;
    private TextField nameField;
    private TextField surnameField;
    private TextField ageField;
    private TextField fileNameField;
    private String profileUrl = "file:src/Peer/imgs/profileAvatar.png";
    private RadioButton selectedGenderRadioButton;
    private BufferedWriter bWriter;
    private BufferedReader bReader;
    private BufferedOutputStream bOutputStream;
    private Socket socket;
    private File selectedFile;

    public AdminUI(Navigator navigator){
        this.navigator = navigator;
        /**********************************Setting/initializing up Socket **************************/
        this.socket=navigator.getSocket();

        /**********************************Initializing the read and write fields***************** */
        try {
            bWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            bReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bOutputStream = new BufferedOutputStream(socket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        setPrefSize(1250, 700);
        setPadding(new Insets(10));
        setVgap(10);
        setHgap(10);
        setAlignment(Pos.CENTER);

        /************************Buttons***********/
        Button addCandidateButton = new Button("Add Candidates");
        Button blockchainButton = new Button("Blockchain");
        Button updateRulesButton = new Button("Update Rules");
        Button logOutButton = new Button("Log Out");
        this.add(addCandidateButton, 0, 0);
        this.add(blockchainButton,0,1);
        this.add(updateRulesButton, 0, 2);
        this.add(logOutButton, 0, 3);
        addCandidateButton.setOnAction(e->{navigator.navigateToAddCandidate();});
        blockchainButton.setOnAction(e->{navigator.navigateToAdminBlockchain();});
        updateRulesButton.setOnAction(e->navigator.navigateToUpdateRules());
        logOutButton.setOnAction(e->navigator.navigateToLogin());
        /*************************style****************/
        styleButton(updateRulesButton);
        styleButton(addCandidateButton);
        styleButton(blockchainButton);
        styleButton(logOutButton);
        this.setStyle(
                        "-fx-background-image: url('Peer/imgs/gradient1.jpg');" +
                        "-fx-background-size: cover;" +
                        "-fx-background-repeat: no-repeat;"
                     );
        
    }
    public static void styleButton(Button btn) {
        btn.setPrefWidth(200);
        btn.setFont(Font.font("Arial", 14));
        btn.setTextFill(Color.WHITE);
        btn.setStyle("-fx-background-color: #1b1d21");
        btn.setOnMouseEntered(e -> btn.setStyle("-fx-background-color: linear-gradient(to bottom, #3c4457, #1e5799);"));
        btn.setOnMouseExited(e -> btn.setStyle("-fx-background-color: #1b1d21"));
    }
    public Scene addCandidate(Stage stage){
        GridPane grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.setPadding(new Insets(10));

        /****************profile*******************/
        Image image = new Image(profileUrl);
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(100);
        imageView.setFitHeight(100);
        GridPane imagePane = new GridPane();
        imagePane.add(imageView, 0, 0);
        
        grid.add(imagePane, 1, 0);

        /****************Labels********************/
        Label nameLabel = new Label("Name:");
        Label surnameLabel = new Label("Surname:");
        Label ageLabel = new Label("Age:");
        Label genderLabel = new Label("Gender:");
        Label profileLabel = new Label("Profile:");
        grid.add(nameLabel, 0, 1);
        grid.add(surnameLabel, 1, 1);
        grid.add(ageLabel, 0, 3);
        grid.add(genderLabel, 0, 4);
        grid.add(profileLabel, 0, 6);
        /****************TextFields****************/
        fileNameField = new TextField();
        fileNameField.setEditable(false);
        nameField = new TextField();
        surnameField = new TextField();
        ageField = new TextField();
        Text status = new Text();
        grid.add(status, 0, 7);
        grid.add(nameField,0, 2);
        grid.add(surnameField, 1, 2);
        grid.add(ageField, 1, 3);
        grid.add(fileNameField,1,6);

        /****************Buttons*******************/ 
        Button backButton = new Button("Back");
        backButton.setOnAction(e->{navigator.navigateToAdmin();});
        RadioButton maleRadioButton = new RadioButton("Male");
        RadioButton femaleRadioButton = new RadioButton("Female");
        Button selectImageButton = new Button("Select Image");
        grid.add(selectImageButton, 2, 6);
        grid.add(maleRadioButton, 1, 4);
        grid.add(femaleRadioButton,1,5);
        ToggleGroup toggleGroup = new ToggleGroup();
        maleRadioButton.setToggleGroup(toggleGroup);
        femaleRadioButton.setToggleGroup(toggleGroup);
        maleRadioButton.setSelected(true);
        selectedGenderRadioButton = maleRadioButton;
        maleRadioButton.setOnAction(e->selectedGenderRadioButton = maleRadioButton);
        femaleRadioButton.setOnAction(e->selectedGenderRadioButton=femaleRadioButton);
        selectImageButton.setOnAction(e -> {
            // Define the directory path you want to open
            String initialDirectoryPath = "src/SampleCandidateImages";
            
            // Create a File object for the initial directory
            File initialDirectory = new File(initialDirectoryPath);
            
            // Check if the directory exists and is indeed a directory
            if (!initialDirectory.exists() || !initialDirectory.isDirectory()) {
                // Handle the case where the directory does not exist or is not a directory
                System.out.println("Invalid directory path: " + initialDirectoryPath);
                return; // Exit the method if the directory is invalid
            }
            
            // Create and configure the file chooser
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Select Image");
            fileChooser.setInitialDirectory(initialDirectory); // Set the initial directory
            
            // Restrict selectable file types
            fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif", "*.webp")
            );
            
            // Show the file chooser dialog
            selectedFile = fileChooser.showOpenDialog(stage);
            
            // Process the selected file
            if (selectedFile != null) {
                fileNameField.setText(selectedFile.getName());
                profileUrl = selectedFile.toURI().toString();
                imageView.setImage(new Image(profileUrl));
            } else {
                fileNameField.setText("No file selected.");
            }
        });
        
        Button addButton = new Button("Add");
        addButton.setOnAction(e -> {
            String result = sendCandidateData();
            if(result!=null){
                if (result.equals("done")) {
                    Platform.runLater(() -> {
                        Alert successAlert = new Alert(AlertType.INFORMATION);
                        successAlert.setTitle("Candidate Added");
                        successAlert.setHeaderText(null);
                        successAlert.setContentText("Candidate has been added successfully.");
                        successAlert.showAndWait();
                    });
                } else {
                    Platform.runLater(() -> {
                        Alert errorAlert = new Alert(AlertType.ERROR);
                        errorAlert.setTitle("Candidate already added");
                        errorAlert.setHeaderText(null);
                        errorAlert.setContentText("Couldn't add the candidate.");
                        errorAlert.showAndWait();
                    });
                }
            }
        });
        GridPane addPane = new GridPane();
        addPane.setVgap(10);
        addPane.setAlignment(Pos.CENTER);
        addPane.add(addButton, 0, 0);
        addPane.add(backButton, 0, 1);
        grid.add(addPane, 0, 8);

        /*********************style*****************/
        grid.setStyle(
            "-fx-background-image: url('Peer/imgs/gradient1.jpg');" +
            "-fx-background-size: cover;" +
            "-fx-background-repeat: no-repeat;"
         );
        styleButton(addButton);
        styleButton(backButton);
        styleButton(selectImageButton);

        return new Scene(grid,1250,700);
    }
    public Scene Blockchain() {
        VBox vBox = new VBox();
        vBox.setSpacing(10);
        vBox.setAlignment(Pos.CENTER);

        // Label
        Label blockchainLabel = new Label("Khetha Blockchain:");
        blockchainLabel.setFont(Font.font(24));
        blockchainLabel.setTextFill(Color.GRAY);
        vBox.getChildren().add(blockchainLabel);

        // Create scroll pane containing a FlowPane to hold the blockchain blocks
        ScrollPane scrollPane = new ScrollPane();
        FlowPane flowPane = new FlowPane();
        flowPane.setPadding(new Insets(20));
        flowPane.setHgap(20);
        flowPane.setVgap(20);
        writeToServer("Blockchain");
        String[] blockData = readFromServer().split("\'\'");

        // Create and add blocks to the FlowPane
        for (int i = 0; i < blockData.length; i++) {
            StackPane blockPane = createBlockPane(i, blockData[i]);
            flowPane.getChildren().add(blockPane);
        }

        scrollPane.setContent(flowPane);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefSize(1100, 500);
        vBox.getChildren().add(scrollPane);

        // Add back and verifyBlockchain button
        Button backButton = new Button("Back");
        Button verifyBlockchainButton = new Button("Verify Blockchain");
        backButton.setOnAction(e -> navigator.navigateToAdmin());
        verifyBlockchainButton.setOnAction(e -> {
            writeToServer("Verify Blockchain");
            if (readFromServer().equals("Valid blockchain")) {
                Platform.runLater(() -> {
                    // Show a success dialog if the blockchain is valid
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Blockchain Verification");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText("The blockchain is valid.");
                    successAlert.showAndWait();
                });
            } else {
                Platform.runLater(() -> {
                    // Show an error dialog if the blockchain is not valid
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setTitle("Blockchain Verification");
                    errorAlert.setHeaderText(null);
                    errorAlert.setContentText("The blockchain is not valid.");
                    errorAlert.showAndWait();
                });
            }
        });
        
        vBox.getChildren().add(verifyBlockchainButton);
        vBox.getChildren().add(backButton);
    
        // Apply styles
        vBox.setStyle(
                "-fx-background-image: url('Peer/imgs/BlockchainBackground1.jpg');" +
                "-fx-background-size: cover;" +
                "-fx-background-repeat: no-repeat;"
        );
        styleButton(backButton);
        styleButton(verifyBlockchainButton);
    
        return new Scene(vBox, 1250, 700);
    }
    
    private StackPane createBlockPane(int blockNumber, String data) {
        // Create a Text node to display the block number and data
        Text blockText = new Text("BLOCK " + blockNumber + ":\n" + data);
        blockText.setFill(Color.BLACK);
        blockText.setWrappingWidth(200);

        // Create a StackPane to hold the text
        StackPane stackPane = new StackPane();
        stackPane.setStyle("-fx-background-color: lightblue; " +
                           "-fx-padding: 10px; " +
                           "-fx-background-radius: 10px;");

        // Add text to the stack pane
        stackPane.getChildren().add(blockText);

        // Add hover effect
        stackPane.setOnMouseEntered(e -> {
            // Apply hover effect when mouse enters the block
            stackPane.setStyle("-fx-background-color: #6e6862; " +
                               "-fx-padding: 15px; " +
                               "-fx-background-radius: 15px;");
            blockText.setFill(Color.WHITE);
        });

        stackPane.setOnMouseExited(e -> {
            // Revert to default styling when mouse exits the block
            stackPane.setStyle("-fx-background-color: lightblue; " +
                               "-fx-padding: 10px; " +
                               "-fx-background-radius: 10px;");
            blockText.setFill(Color.BLACK);
        });

        return stackPane;
    }
    public Scene updateRules() {
        TextArea rulesTextArea = new TextArea();
        rulesTextArea.setWrapText(true);
        rulesTextArea.setEditable(true);
        try (BufferedReader reader = new BufferedReader(new FileReader("src/Peer/data/info.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                rulesTextArea.appendText(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace(); 
        }
        Button saveButton = new Button("Save");
        saveButton.setOnAction(e -> {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/Peer/data/info.txt"))) {
                writer.write(rulesTextArea.getText());
                writer.flush();
            } catch (IOException ex) {
                ex.printStackTrace(); 
            }
            Platform.runLater(() -> {
                Alert successAlert = new Alert(AlertType.INFORMATION);
                successAlert.setTitle("Info Update");
                successAlert.setHeaderText(null);
                successAlert.setContentText("Voting Information has been updated succesfully");
                successAlert.showAndWait();
            });
        });
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> navigator.navigateToAdmin());
        // Create the main grid for the scene
        GridPane grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.setPadding(new Insets(10));
        grid.add(rulesTextArea, 0, 0);
        grid.add(saveButton, 0, 1);
        grid.add(backButton, 0, 2);
        // Apply styles
        grid.setStyle(
                "-fx-background-image: url('Peer/imgs/gradient1.jpg');" +
                "-fx-background-size: cover;" +
                "-fx-background-repeat: no-repeat;"
        );
        styleButton(saveButton);
        styleButton(backButton);
        return new Scene(grid, 1250, 700);
    }

    private String readFromServer(){
        String response=null;
        try{
            response = bReader.readLine();
        }catch(Exception e){
            e.printStackTrace();
        }
        return response;
    }

    private void writeToServer(String string){
        try{
            bWriter.write(string);
            bWriter.newLine();
            bWriter.flush();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private String sendCandidateData(){
        writeToServer("ADD CANDIDATE");
        if(nameField.getText().isEmpty()|| surnameField.getText().isEmpty()||ageField.getText().isEmpty()||fileNameField.getText().isEmpty()){
            // Show alert for empty fields
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Upload Error");
            alert.setHeaderText(null);
            alert.setContentText("Please fill out all fields and select the file.");
            alert.showAndWait();
        }else{
            writeToServer(nameField.getText()+"\'"+surnameField.getText()+"\'"+ageField.getText()+"\'"+selectedGenderRadioButton.getText()+"\'"+fileNameField.getText()+"\'"+selectedFile.length());
            System.out.println("cred Sent!");
            String response = readFromServer();
            System.out.println("resp received");
            if(response.equals("credentials received")){
                try(FileInputStream fileInputStream = new FileInputStream(selectedFile)){
                    byte[] buffer = new byte[1024];
                    int read=0;
                    while((read=fileInputStream.read(buffer))!=-1){
                        bOutputStream.write(buffer, 0, read);
                    }
                    System.out.println("file sent");
                    bOutputStream.flush();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            response = readFromServer();
            System.out.println(" done resp received");
            return response;
        }
        return null;
    }
}