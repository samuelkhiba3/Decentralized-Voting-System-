package Peer.UI;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class VoteUIInfo extends BorderPane {
    @SuppressWarnings("unused")
    private Navigator navigator;
    private final String path= "src/Peer/data/info.txt"; //sets the path of where the vote information text is kept 
    ;
    public VoteUIInfo(Navigator navigator) {
        setPrefSize(1250, 700);
        this.navigator = navigator;
        VBox vBox = new VBox();
        vBox.setAlignment(Pos.CENTER);
        setCenter(vBox);

        // Label
        Label voteInfoLabel = new Label("Vote Information:");
        voteInfoLabel.setFont(Font.font(24));
        vBox.getChildren().add(voteInfoLabel);

        // Text
        Text text = new Text();
        text.setFont(Font.font("Arial",16));
        text.setWrappingWidth(1000); // Set the preferred width for text wrapping
        String content = readTextFromFile(path);
        text.setText(content);
        ScrollPane scrollPane = new ScrollPane(text);
        scrollPane.setPrefViewportWidth(1000); // Set preferred width of the scroll pane
        scrollPane.setPrefViewportHeight(500); // Set preferred height of the scroll pane
        vBox.getChildren().add(scrollPane);

        // Button
        Button backButton = new Button("Back");
        vBox.getChildren().add(backButton);
        backButton.setOnAction(e -> navigator.navigateToWelcome());

        // Style
        WelcomeUI.styleButton(backButton);
        this.setStyle(
                        "-fx-background-image: url('Peer/imgs/whiteTallBuildings.jpg');" +
                        "-fx-background-size: cover;" +
                        "-fx-background-repeat: no-repeat;"
                     );
        voteInfoLabel.setTextFill(Color.GRAY);
    }

    private String readTextFromFile(String filePath) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }
}
