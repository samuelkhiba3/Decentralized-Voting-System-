package Peer.UI;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class WelcomeUI extends GridPane {

    @SuppressWarnings("unused")
    private final Navigator navigator;
    
    public WelcomeUI(Navigator navigator) {
        setPrefSize(1250, 700);
        this.navigator = navigator;
        
        setPadding(new Insets(10));
        setHgap(10);
        setVgap(30);
        setAlignment(Pos.CENTER);

        /******************* Label**********************/
        GridPane welcomePane = new GridPane(); 
        welcomePane.setAlignment(Pos.CENTER); 
        Label welcomeLabel = new Label("WELCOME");
        welcomeLabel.setFont(Font.font(24)); // Set larger font size
        welcomePane.add(welcomeLabel, 0, 0, 2, 1);
        this.add(welcomePane, 0, 0);

        /******************* Buttons********************/
        GridPane buttonPane = new GridPane(); //separate pane for buttons
        buttonPane.setAlignment(Pos.CENTER); // Center the buttons within the pane
        buttonPane.setVgap(10);

        Button loginButton = new Button("LogIn");
        Button registerButton = new Button("Register");
        Button votingInfoButton = new Button("Voting Information");
        buttonPane.add(loginButton, 0, 0);
        buttonPane.add(registerButton, 0, 1);
        buttonPane.add(votingInfoButton, 0, 2);
        loginButton.setOnAction(e -> {
            navigator.navigateToLogin();
        });
        registerButton.setOnAction(e -> {
            navigator.navigateToRegistration();
        });
        votingInfoButton.setOnAction(e -> {
            navigator.navigateToVoteInfo();
        });
        this.add(buttonPane, 0, 1); 

        /********************** Styles **********************/
        WelcomeUI.styleButton(loginButton);
        WelcomeUI.styleButton(votingInfoButton);
        WelcomeUI.styleButton(registerButton);
        this.setStyle(
                        "-fx-background-image: url('Peer/imgs/whiteTallBuildings.jpg');" +
                        "-fx-background-size: cover;" +
                        "-fx-background-repeat: no-repeat;"
                     );
        welcomeLabel.setTextFill(Color.rgb(41, 137, 216));
    }
    public static void styleButton(Button btn) {
        btn.setPrefWidth(200);
        btn.setFont(Font.font("Arial", 14));
        btn.setTextFill(Color.WHITE);
        btn.setStyle("-fx-background-color: #5B738BD4");
        btn.setOnMouseEntered(e -> btn.setStyle("-fx-background-color: linear-gradient(to bottom, #2989d8, #1e5799);"));
        btn.setOnMouseExited(e -> btn.setStyle("-fx-background-color: #5B738BD4"));
    }
    
}
