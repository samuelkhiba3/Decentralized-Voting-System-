package Peer.UI;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import Peer.Networking.PeerNetwork;

public class BlockchainUI extends BorderPane {
    @SuppressWarnings("unused")
    private Navigator navigator;

    public BlockchainUI(Navigator navigator) {
        this.navigator = navigator;
        setPrefSize(1250, 700);

        VBox vBox = new VBox();
        vBox.setSpacing(10);
        vBox.setAlignment(Pos.CENTER);
        setCenter(vBox);

        // Label
        Label blockchainLabel = new Label("Peer Blockchain:");
        blockchainLabel.setFont(Font.font(24));
        blockchainLabel.setTextFill(Color.WHITE);
        vBox.getChildren().add(blockchainLabel);

        // Create scroll pane containing a FlowPane to hold the blockchain blocks
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setStyle("-fx-background-color: transparent;");
        FlowPane flowPane = new FlowPane();
        flowPane.setPadding(new Insets(20));
        flowPane.setHgap(20);
        flowPane.setVgap(20);

        String[] blockData = PeerNetwork.getBlockchain().toString().split("\n");
        // Create and add blocks to the FlowPane
        for (int i = 0; i < blockData.length; i++) {
            StackPane blockPane = createBlockPane(i, blockData[i]);
            flowPane.getChildren().add(blockPane);
        }

        scrollPane.setContent(flowPane);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefSize(1100, 500);
        vBox.getChildren().add(scrollPane);

        // Buttons
        Button backButton = new Button("Back");
        Button verifyButton = new Button("Verify Blockchain");
        vBox.getChildren().addAll(verifyButton, backButton);

        backButton.setOnAction(e -> navigator.navigateToUserMenu());
        verifyButton.setOnAction(e -> {
            boolean isValid = PeerNetwork.getBlockchain().isChainValid();
            String message = isValid ? "The blockchain is valid." : "The blockchain is not valid.";
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Blockchain Verification");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });

        // Apply styles to buttons
        WelcomeUI.styleButton(backButton);
        WelcomeUI.styleButton(verifyButton);

        // Set background image
        this.setStyle("-fx-background-image: url('Peer/imgs/BlockchainBackground1.jpg');" +
                      "-fx-background-size: cover;" +
                      "-fx-background-repeat: no-repeat;");
    }

    private StackPane createBlockPane(int blockNumber, String data) {
        // Create a Text node to display the block number and data
        Text blockText = new Text("BLOCK " + blockNumber + ":\n" + data);
        blockText.setFill(Color.BLACK);
        blockText.setWrappingWidth(200);

        // Create a StackPane to hold the text
        StackPane stackPane = new StackPane();
        stackPane.setStyle("-fx-background-color: lightblue; " +
                           "-fx-padding: 10px; " +
                           "-fx-background-radius: 10px;");

        // Add text to the stack pane
        stackPane.getChildren().add(blockText);

        // Add hover effect
        stackPane.setOnMouseEntered(e -> {
            // Apply hover effect when mouse enters the block
            stackPane.setStyle("-fx-background-color: #000000; " +
                               "-fx-padding: 15px; " +
                               "-fx-background-radius: 15px;");
            blockText.setFill(Color.WHITE);
        });

        stackPane.setOnMouseExited(e -> {
            // Revert to default styling when mouse exits the block
            stackPane.setStyle("-fx-background-color: lightblue; " +
                               "-fx-padding: 10px; " +
                               "-fx-background-radius: 10px;");
            blockText.setFill(Color.BLACK);
        });

        return stackPane;
    }
}
