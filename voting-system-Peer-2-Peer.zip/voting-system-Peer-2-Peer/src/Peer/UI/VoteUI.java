package Peer.UI;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

import DSA.SinglyLinkedList;
import Khetha.Election.Voter;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class VoteUI extends BorderPane{
    @SuppressWarnings("unused")
    private Navigator navigator;
    private BufferedReader bReader;
    private BufferedWriter bWriter;
    private Socket socket;
    private SinglyLinkedList<Candidate> candidates;
    private BufferedInputStream bInputStream;
    private ToggleGroup toggleGroup;

    public VoteUI(Navigator navigator){
        this.navigator = navigator;

        /**********************************Setting/initializing up Socket **************************/
        this.socket = navigator.getSocket();
         /********************************************************************************************/

        this.setPrefSize(1250, 700);
        candidates = new SinglyLinkedList<>();

        /**********************************Initializing the read and write fields******************/
        try {
            bReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bWriter=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            bInputStream = new BufferedInputStream(socket.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
        }
        /********************************************************************************************/
        
        VBox candidateBox = new VBox();
        candidateBox.setSpacing(10);
        candidateBox.setPadding(new Insets(10));
        candidateBox.setAlignment(Pos.TOP_CENTER);
        ScrollPane scrollPane = new ScrollPane(candidateBox);
        scrollPane.setFitToWidth(true);

        /***********Requesting Commision to send available Candidates to vote for*****************/
        writeToServer("Vote");
        new Thread(()->retrieveCandidates()).start(); //retrieving on separate thread to avoid Gui from waiting
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {

        @Override
        public void run() {
            Platform.runLater(() -> {
            System.out.println("Linked list size: "+candidates.size());
            for(Candidate temp : candidates){
                candidateBox.getChildren().add(temp);
            }
            });
        }
        },350); // Delay in milliseconds so they can all be retreved successfully
        /********************************************************************************************/
       
        Label candidateLabel = new Label("Candidates:");
        candidateLabel.setFont(Font.font(24));
        candidateLabel.setTextFill(Color.rgb(41, 137, 216));

        /*********************************Buttons**************************************************** */
        Button submitButton = new Button("Submit");
        Button backButton = new Button("Back");
        toggleGroup = new ToggleGroup();
         /********************************************************************************************/

        /*********************************Submitting selected candidate to the commision************ */
        submitButton.setOnAction(e -> {
            // Find the selected candidate
            Candidate selectedCandidate = null;
            for (Node node : candidateBox.getChildren()) {
                if (node instanceof Candidate) {
                    Candidate candidate = (Candidate) node;
                    RadioButton radioButton = candidate.getRadioButton();
                    if (radioButton.isSelected()) {
                        selectedCandidate = candidate;
                        break;
                    }
                }
            }

            // If a candidate is selected, retrieve details and process
            if (selectedCandidate != null) {
                String candidateName = selectedCandidate.getName();
                String candidateSurname = selectedCandidate.getSurname();
                int candidateAge = selectedCandidate.getAge();
                String candidateGender = selectedCandidate.getGender();
                String candidateId = selectedCandidate.getid();

                // Processing the selected candidate details 
                System.out.println("Selected Candidate: " + candidateName + " " + candidateSurname);
                System.out.println("Age: " + candidateAge + ", Gender: " + candidateGender +" ID:"+candidateId);
                if(submitVote(candidateId)){ //if true is parsed then Vote was successfully cast.
                    Alert successAlert = new Alert(AlertType.INFORMATION);
                    successAlert.setTitle("Vote cast succesful");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText("You voted for: "+candidateName+" "+candidateSurname+" with ID: "+candidateId);
                    successAlert.showAndWait();
                }else{//else vote couldn't be cast
                    Alert successAlert = new Alert(AlertType.ERROR);
                    successAlert.setTitle("Already Voted");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText( "Can not cast vote more than once!");
                    successAlert.showAndWait();
                }
            }
        });
        /********************************************************************************************/
        
        //When clicked directs you to Menu options
        backButton.setOnAction(e->{
            navigator.navigateToUserMenu();
        });
        
        /***************style****************/
        WelcomeUI.styleButton(submitButton);
        WelcomeUI.styleButton(backButton);
        this.setStyle(
                        "-fx-background-image: url('Peer/imgs/whiteTallBuildings.jpg');" +
                        "-fx-background-size: cover;" +
                        "-fx-background-repeat: no-repeat;"
                     );
        /********************************* */

        VBox root = new VBox(candidateLabel,scrollPane, submitButton,backButton);
        root.setSpacing(10);
        root.setAlignment(Pos.CENTER);
        this.setCenter(root);
    }
;
    //used to submit a vote to commision
    private boolean submitVote(String candidateId) {
        boolean voted = false;
        try {
            Voter voter=null;
            writeToServer("SUBMIT VOTE");
            writeToServer(LogInUI.getTempKey()); //sending key for recognison at the commision side
            writeToServer(candidateId);
            String response = readFromServer(); //reads responds from the server whether the peer is elegible to vote or not
            if(response.equals("ALREADY VOTED")){
                return voted; //return falde (vote unsuccesful cast);
            }else if(response.equals("SENDING VOTER DETAILS")){
                voter = receiveVoterDetails();
                String transactionString = voter.getName()+"\'\'Khetha(Vote)\'\'"+voter.toString(); //After successful vote submission the transaction is created and added to the current peer blockchain
                writeToServer(transactionString);//transaction is also passed to the commision to be broadcasted to other peer too.
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return !voted; //return true (vote succesful cast)
    }

    //This method is used to extract current peer details of which will be used when sending transaction for sender detail and relevent actions
    private Voter receiveVoterDetails(){
        ObjectInputStream objInputStream;
        try {
            objInputStream = new ObjectInputStream(socket.getInputStream());
            return (Voter) objInputStream.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    //Use to setup candidate profiles along with their relevant details during retrieval of the Candidates from the commision
    private class Candidate extends GridPane {
        private String name;
        private String surname;
        private String id;
        private int age;
        private String gender;
        private RadioButton radioButton;
        public Candidate(String name,String surname,String id,int age, String gender,String profileName ) {
            this.age=age;
            this.gender=gender;
            this.name=name;
            this.surname=surname;
            this.id = id;
            setPadding(new Insets(10));
            setHgap(10);
            setVgap(5);

            //retrieved profile image is kept in a cache folder to avoid asking for images of the candidate during futrure retrieval
            File file = new File("src/Peer/cache/imgs/"+profileName);
            System.out.println("File exists: "+file.exists());
            Image image = new Image("file:src/Peer/cache/imgs/"+profileName);
            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(100);
            imageView.setFitHeight(100);

            //labels
            Label nameLabel = new Label("Name:");
            Label ageLabel = new Label("Age:");
            Label genderLabel = new Label("Gender:");
            Label IDLabel = new Label("Public ID  :");
            Label surnameLabel = new Label("Surname");

            //textfields
            TextField nameField = new TextField(name);
            nameField.setEditable(false);
            TextField ageField = new TextField(Integer.toString(age));
            ageField.setEditable(false);
            TextField genderField = new TextField(gender);
            genderField.setEditable(false);
            TextField surnameField = new TextField(surname);
            surnameField.setEditable(false);
            TextField idField = new TextField(id);
            idField.setEditable(false);
            
            radioButton = new RadioButton("Select");
            radioButton.setToggleGroup(toggleGroup);

            add(imageView, 0, 0, 1, 4);
            add(nameLabel, 1, 0);
            add(nameField, 2, 0);
            add(surnameLabel,3,0);
            add(surnameField, 4,0);
            add(ageLabel, 1, 1);
            add(ageField, 2, 1);
            add(genderLabel, 1, 2);
            add(genderField, 2, 2);
            add(IDLabel, 1, 3);
            add(idField,2,3);
            add(radioButton, 5, 0, 1, 4);

            this.setStyle("-fx-border-color: #b3c3c7;"+
                            "-fx-background-color: #f7f7f7" );
            this.setOnMouseEntered(e -> this.setStyle("-fx-background-color: linear-gradient(to bottom,#f5f7f7, #d7dadb)"));
            this.setOnMouseExited(e -> this.setStyle("-fx-background-color: #f7f7f7;"+
                                    "-fx-border-color: #b3c3c7;"));
        }
        public RadioButton getRadioButton() {
            return radioButton;
        }
        public String getName() {
            return name;
        }
        public String getSurname() {
            return surname;
        }
        public String getGender() {
            return gender;
        }
        public int getAge() {
            return age;
        }
        public String getid() {
            return id;
        }
    }

    //sends retrieval of candidates request to the commision
    private void retrieveCandidates(){
        if(readFromServer().equals("retrieval request received")){
            try{
                writeToServer("send data");
                while(true){
                    String response = readFromServer();
                    if(response!=null && !response.equals("Candidate data sent")){
                        System.out.println(response);
                        String[] candidateData = response.split("\'");
                        //Extract candidate information
                        String candidateId = candidateData[0];
                        String name = candidateData[1];
                        String surname = candidateData[2];
                        int age = Integer.parseInt(candidateData[3]);
                        String gender = candidateData[4];
                        String profileName = candidateData[5];
                        long profileSize = Long.parseLong(candidateData[6]);
                    
                        // Download candidate image from server
                        writeToServer("send profile");
                        downloadCandidateImage(name,surname,candidateId,age,gender,profileName,profileSize);
                        response=null;
                    } else {
                        System.out.println(response);
                        break;
                    }
                }
            } catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    //handles the retrieved images of which are received using the stream and sockets
    private void downloadCandidateImage(String name, String surname,String id, int age, String gender, String profileName,long size){
        try {
            File file = new File("src/Peer/cache/imgs/"+profileName);
            
            if(!file.exists()){ //if the image is not available in the cache, it notifies the server to send the image
                writeToServer("notCached");
                // Downloading candidate image from the server
                System.out.println("Downloading candidate image: " + profileName);
                BufferedOutputStream fileOutputStream = new BufferedOutputStream(new FileOutputStream(file));
                byte[] buffer = new byte[1024];
                int read;
                long totalBytesRead = 0;
                while((totalBytesRead<size) && (read=bInputStream.read(buffer)) != -1){
                    fileOutputStream.write(buffer, 0, read);
                    totalBytesRead+=read;
                }
                fileOutputStream.flush();
                fileOutputStream.close();
                System.out.println("Candidate image downloaded: " + profileName);
           }else{ //Notifies the commision that it shouldn't bother sending images as they already exist in the cache
                writeToServer("cached");
                System.out.println("Image already in the cached memory");
           }
           candidates.addFirst(new Candidate(name, surname,id, age, gender, profileName)); //candidate is added to candidates list profile per response from the commision
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String readFromServer(){
        String response=null;
        try{
            response = bReader.readLine();
        }catch(Exception e){
            e.printStackTrace();
        }
        return response;
    }

    private void writeToServer(String string){
        try{
            bWriter.write(string);
            bWriter.newLine();
            bWriter.flush();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
