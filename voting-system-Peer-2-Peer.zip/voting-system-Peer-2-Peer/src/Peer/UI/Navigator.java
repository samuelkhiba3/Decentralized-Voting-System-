package Peer.UI;
import java.net.Socket;

import Khetha.Election.Voter;
import Peer.Networking.PeerNetwork;
import acsse.csc03a3.Blockchain;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Navigator {
    private Stage stage;
    private Socket socket;
    private Blockchain<Voter> peerBlockchain;

    public Blockchain<Voter> getPeerBlockchain() {
        return peerBlockchain;
    }

    public Socket getSocket() {
        return socket;
    }

    public Navigator(Stage stage) {
        socket= new PeerNetwork().getSocket();
        this.stage = stage;
        peerBlockchain = new Blockchain<>();
    }

    public void navigateToWelcome() {
        WelcomeUI welcome = new WelcomeUI(this);
        peerBlockchain = new Blockchain<>();
        peerBlockchain.registerStake("Voter", 250);
        Scene scene = new Scene(welcome);
        stage.setScene(scene);
        stage.setTitle("Welcome");
    }

    public void navigateToLogin() {
        LogInUI login = new LogInUI(this);
        Scene scene = new Scene(login);
        stage.setScene(scene);
        stage.setTitle("LogIn");
    }
    public void navigateToVoteInfo(){
        VoteUIInfo voteInfo = new VoteUIInfo(this);
        Scene scene  = new Scene(voteInfo);
        stage.setScene(scene);
        stage.setTitle("Information");
    }
    public void navigateToRegistration(){
        RegisterUI register = new RegisterUI(this);
        Scene scene = new Scene(register);
        stage.setScene(scene);
        stage.setTitle("Register");
    }
    public void navigateToAdmin(){
        AdminUI admin = new AdminUI(this);
        Scene scene = new Scene(admin);
        stage.setScene(scene);
        stage.setTitle("Admin Menu");
    }
    public void navigateToAddCandidate(){
        AdminUI admin = new AdminUI(this);
        Scene scene = admin.addCandidate(stage);
        stage.setScene(scene);
        stage.setTitle("Add Candidate");
    }
    public void navigateToAdminBlockchain(){
        AdminUI admin = new AdminUI(this);
        Scene scene = admin.Blockchain();
        stage.setScene(scene);
        stage.setTitle("Blockchain");
    }
    public void navigateToPeerResults(){
        ResultsUI resultsUI = new ResultsUI(this);
        Scene scene = new Scene(resultsUI);
        stage.setScene(scene);
        stage.setTitle("Results");
    }
    public void navigateToUpdateRules(){
        AdminUI admin = new AdminUI(this);
        Scene scene = admin.updateRules();
        stage.setScene(scene);
        stage.setTitle("Update rules");
    }
    public void navigateToUserMenu(){
        MenuUI menu = new MenuUI(this);
        Scene scene = new Scene(menu);
        stage.setScene(scene);
        stage.setTitle("Menu");
    }

    public void navigateToVote() {
        VoteUI vote = new VoteUI(this);
        Scene scene = new Scene(vote);
        stage.setScene(scene);
        stage.setTitle("Vote");
    }
    public void navigateToPeerBlockChain() {
        BlockchainUI blockchainUI = new BlockchainUI(this);
        Scene scene = new Scene(blockchainUI);
        stage.setScene(scene);
        stage.setTitle("Blockchain");
    }
    public void navigateToVoteVerification(){
        VoteVerificationUI voteVerification = new VoteVerificationUI(this);
        if(voteVerification.isVerificationAvailable()){
            Scene scene = new Scene(voteVerification);
            stage.setScene(scene);
            stage.setTitle("Vote Verification");
        }
    }
    public Stage getStage() {
        return stage;
    }
}

