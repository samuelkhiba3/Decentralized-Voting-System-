package Peer.UI;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import Security.Security;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class RegisterUI extends GridPane{
    private TextField iDField;
    private TextField nameField;
    private TextField surnameField;
    private PasswordField passwordField;
    @SuppressWarnings("unused")
    private Navigator navigator;
    private TextField ageField;
    @SuppressWarnings("unused")
    private Socket socket;
    private Text privateKey;
    private RadioButton selectedGenderRadioButton;
    private BufferedWriter bWriter;
    private BufferedReader bReader;
    
    public RegisterUI(Navigator navigator){
        this.navigator=navigator;

        /**********************************Setting/initializing up Socket **************************/
        this.socket= navigator.getSocket();

        /**********************************Initializing the read and write fields***************** */
        try {
            bWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            bReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        this.setVgap(15);
        setPrefSize(1250, 700);
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));
        setAlignment(Pos.CENTER);

        /**************labels***************/
        GridPane registerPane = new GridPane();
        registerPane.setAlignment(Pos.CENTER);
        Label iDLabel = new Label("ID:");
        Label nameLabel = new Label("Name:");
        Label surnameLabel = new Label("Surname:");
        Label registerLabel = new Label("Registration");
        Label passwordLabel = new Label("Password:");
        Label genderLabel = new Label("Gender:");
        Label ageLabel = new Label("Age:");
        registerLabel.setFont(Font.font(24));
        registerPane.add(registerLabel, 0, 0);

        this.add(registerPane,0,0);
        grid.add(nameLabel, 0, 1);
        grid.add(surnameLabel, 1, 1);
        grid.add(iDLabel, 0, 3);
        grid.add(ageLabel, 1, 3);
        grid.add(genderLabel,0,5);
        grid.add(passwordLabel,0,7);

        /**************TextField/TextArea/passwordField***/
        iDField = new TextField();
        nameField = new TextField();
        surnameField = new TextField();
        passwordField = new PasswordField();
        ageField = new TextField();
        privateKey = new Text();
        grid.add(nameField, 0, 2);
        grid.add(surnameField, 1, 2);
        grid.add(iDField, 0, 4);
        grid.add(ageField, 1, 4);
        grid.add(passwordField, 0, 8);

        /**************Buttons**************/
        RadioButton maleRadioButton = new RadioButton("Male");
        RadioButton femaleRadioButton = new RadioButton("Female");
        ToggleGroup toggleGroup = new ToggleGroup();
        maleRadioButton.setToggleGroup(toggleGroup);
        femaleRadioButton.setToggleGroup(toggleGroup);
        femaleRadioButton.setSelected(true);
        selectedGenderRadioButton = femaleRadioButton;
        maleRadioButton.setOnAction(e -> selectedGenderRadioButton = maleRadioButton);
        femaleRadioButton.setOnAction(e -> selectedGenderRadioButton = femaleRadioButton);
        Button registerButton = new Button("Register");
        Button copyButton = new Button("Copy Key");
        Button backButton = new Button("Back");

        //setting the copy button icon image
        Image copyIcon = new Image("file:src/Peer/icons/copy.png");
        ImageView copyIconView = new ImageView(copyIcon);
        copyIconView.setFitHeight(20);
        copyIconView.setFitWidth(20);
        copyButton.setGraphic(copyIconView);

        //inserting buttons into grid
        grid.add(registerButton, 0, 9);
        grid.add(maleRadioButton, 1, 6);
        grid.add(femaleRadioButton, 1, 5);

        //When button clicked, perform the specified action
        registerButton.setOnAction(e->{
            if (passwordField.getText().isEmpty() || nameField.getText().isEmpty() || surnameField.getText().isEmpty()
                    || iDField.getText().isEmpty() || ageField.getText().isEmpty()) {
                // At least one required field is empty or not selected
                Alert alert = new Alert(Alert.AlertType.ERROR, "Please fill out all required fields.", ButtonType.OK);
                alert.showAndWait(); // Display the alert and wait for user response
            } else {
                // All required fields are filled, proceed with registration
                new Thread(this::sendRegistration).start(); // Start registration in a new thread

                // Update UI on the JavaFX Application Thread
                Platform.runLater(() -> {
                    registerButton.setDisable(true);
                    registerButton.setOpacity(0);
                    privateKey.setFont(Font.font("Arial", 16));
                    grid.add(privateKey, 0, 9);
                    grid.add(copyButton,1,9);
                });
            }
            
        });

        //when copyButton is clicked private key is copied to the clipboard
        copyButton.setOnAction(e->{
            String key = privateKey.getText().split(":")[1];
            String textToCopy = key;
            ClipboardContent content = new ClipboardContent();
            content.putString(textToCopy);
            Clipboard.getSystemClipboard().setContent(content);
            copyButton.setText("copied");
        });

        backButton.setOnAction(e->{navigator.navigateToWelcome();});

        this.add(grid,0,1);

        GridPane backPane = new GridPane();
        backPane.setAlignment(Pos.CENTER);
        backPane.getChildren().add(backButton);
        this.add(backPane,0,2);

        /********************style*****************/
        WelcomeUI.styleButton(backButton);
        WelcomeUI.styleButton(registerButton);
        nameLabel.setFont(Font.font(14));
        surnameLabel.setFont(Font.font(14));
        passwordLabel.setFont(Font.font(14));
        iDLabel.setFont(Font.font(14));
        this.setStyle(
                        "-fx-background-image: url('Peer/imgs/whiteTallBuildings.jpg');" +
                        "-fx-background-size: cover;" +
                        "-fx-background-repeat: no-repeat;"
                     );
        grid.setStyle("-fx-border-color: #b3c3c7");
        registerLabel.setTextFill(Color.rgb(41, 137, 216));
    }
    private String readFromServer() {
        String response = null;
        try{
            response = bReader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    private void writeToServer(String string) {
        try{
            bWriter.write(string);
            bWriter.newLine();
            bWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void sendRegistration() {
        writeToServer("Register");
        writeToServer(Security.hash(passwordField.getText())+"\'"+nameField.getText()+"\'"+surnameField.getText()+"\'"+iDField.getText()
                    +"\'"+ageField.getText()+"\'"+selectedGenderRadioButton.getText()+"\'"+null);           
        privateKey.setText(readFromServer());
               
    }
    
}


    
