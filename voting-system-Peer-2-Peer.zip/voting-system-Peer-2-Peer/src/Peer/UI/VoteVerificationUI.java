package Peer.UI;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class VoteVerificationUI extends GridPane{
    private BufferedReader bReader;
    private BufferedWriter bWriter;
    private BufferedInputStream bInputStream;
    @SuppressWarnings("unused")
    private Navigator navigator;
    private Socket socket;
    private Label statusLabel;
    private TextField nameField;
    private TextField surnameField;
    private TextField ageField;
    private TextField idField;
    private Button backButton;
    private boolean verificationAvailable =false;
    private ImageView imageView;

    public VoteVerificationUI(Navigator navigator){
        this.navigator = navigator;
        this.socket = navigator.getSocket();
        this.setPrefSize(1250, 700);
        this.setPadding(new Insets(10));
        this.setHgap(10);
        this.setVgap(10);
        setAlignment(Pos.CENTER);

        /*******************Setting/initializing the read and write streams*************************/
        try {
            bReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bWriter=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            bInputStream = new BufferedInputStream(socket.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
        }
        /********************************************************************************************/

        /****************************************TextFields******************************************/
        nameField = new TextField();
        nameField.setEditable(false);
        surnameField = new TextField();
        surnameField.setEditable(false);
        ageField = new TextField();
        ageField.setEditable(false);
        idField = new TextField();
        idField.setEditable(false);
        /********************************************************************************************/

        /********************************************buttons******************************************/
        backButton = new Button("Back");
        backButton.setOnAction(e->navigator.navigateToUserMenu());
        /********************************************************************************************/

        //initializing imageviewer
        imageView = new ImageView();
        imageView.setFitWidth(100);
        imageView.setFitHeight(100);

        /*********************************************labels*****************************************/
        Label nameLabel = new Label("Name:");
        Label surnameLabel = new Label("Surname:");
        Label ageLabel = new Label("Age:");
        Label idLabel = new Label("ID:");
        statusLabel = new Label("Your Vote");
        statusLabel.setFont(Font.font(24));
        statusLabel.setTextFill(Color.rgb(41, 137, 216));
        this.add(statusLabel,1,0,1,3);
        this.add(imageView, 0, 1);
        this.add(nameLabel,0,2);
        this.add(nameField,1,2);
        this.add(surnameLabel,0,3);
        this.add(surnameField, 1, 3);
        this.add(ageLabel,0,4);
        this.add(ageField, 1, 4);
        this.add(idLabel,0,5);
        this.add(idField, 1, 5);
        this.add(backButton,0,7);    

        verificationAvailable=retrieveChosenCandidate(); //Checks if the peer has voted for a candidate before, if yes it returs true and changes the scene to voted candidates unless otherwise
        
        /*************************************Styling***************************************/
        WelcomeUI.styleButton(backButton);
        this.setStyle(
                        "-fx-background-image: url('Peer/imgs/whiteTallBuildings.jpg');" +
                        "-fx-background-size: cover;" +
                        "-fx-background-repeat: no-repeat;"
                     );
        /***********************************************************************************/
    }
    //Returns true if the voter has cast vote before.
    public boolean isVerificationAvailable() {
        System.out.println(verificationAvailable);
        return verificationAvailable;
    }

    //Retrieves the peer chosen candidate
    private boolean retrieveChosenCandidate(){
        writeToServer("Voted Candidate");
        writeToServer("KEY\'"+LogInUI.getTempKey());
        String candidateDetails = readFromServer();
        System.out.println(candidateDetails);
        if(candidateDetails.equals("Not Found")){
           Alert successAlert = new Alert(AlertType.INFORMATION);
           successAlert.setTitle("Vote verification is unavailable");
           successAlert.setHeaderText(null);
           successAlert.setContentText("Vote has not been cast yet!");
           successAlert.showAndWait(); 
        }else if(candidateDetails.startsWith("CANDIDATE DETAILS")){
            String name = candidateDetails.split("\'")[1];
            String surname = candidateDetails.split("\'")[2];
            String age = candidateDetails.split("\'")[3];
            String id = candidateDetails.split("\'")[4];
            //file size
            Long size = Long.parseLong(candidateDetails.split("\'")[5]);
            //profile name
            String profile = candidateDetails.split("\'")[6];
            try{
                File file = new File("src/Peer/cache/imgs/"+profile);
                if(!file.exists()){
                    writeToServer("SEND PROFILE");
                    BufferedOutputStream fileOutputStream = new BufferedOutputStream(new FileOutputStream(file));
                    byte[] buffer = new byte[1024];
                    int read;
                    long totalBytesRead = 0;
                    while((totalBytesRead<size) && (read=bInputStream.read(buffer)) != -1){
                        fileOutputStream.write(buffer, 0, read);
                        totalBytesRead+=read;
                    }
                    fileOutputStream.flush();
                    fileOutputStream.close();
                }else{
                    writeToServer("DONT SEND PROFILE");
                }
            }catch(Exception e){
                e.printStackTrace();
            }
            
            Platform.runLater(()->{
                //setting label texts
                nameField.setText(name);
                surnameField.setText(surname);
                ageField.setText(age);
                idField.setText(id);

                //setting profile of the chosen candidate
                imageView.setImage(new Image("file:src/Peer/cache/imgs/"+profile));
            });
            return true;
        }
        return false;
    }
    private String readFromServer(){
        String response=null;
        try{
            response = bReader.readLine();
        }catch(Exception e){
            e.printStackTrace();
        }
        return response;
    }

    private void writeToServer(String string){
        try{
            bWriter.write(string);
            bWriter.newLine();
            bWriter.flush();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}