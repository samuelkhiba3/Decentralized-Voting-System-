package Peer.UI;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class MenuUI extends GridPane {
    @SuppressWarnings("unused")
    private Navigator navigator;
    public MenuUI(Navigator navigator) {
        this.setPrefSize(1250, 700);
        this.navigator = navigator;
        this.setPadding(new Insets(10));
        this.setHgap(10);
        this.setVgap(30);

        this.setAlignment(Pos.CENTER);
        /*******************text**********************/
        GridPane menuPane = new GridPane(); // Create a separate pane for buttons
        menuPane.setAlignment(Pos.CENTER); // Center the buttons within the pane

        Label menuLabel = new Label("Menu");
        menuPane.add(menuLabel, 0, 0,2,1);

        this.add(menuPane, 0, 0);
        /*******************buttons*******************/
        GridPane buttonPane = new GridPane(); // Create a separate pane for buttons
        buttonPane.setAlignment(Pos.CENTER); // Center the buttons within the pane
        buttonPane.setVgap(10);
        Button voteButton = new Button("Vote");
        Button voteVerificationButton = new Button("Vote Verification");
        Button resultsButton = new Button("Results");
        Button logOutButton = new Button("LogOut");
        Button peerBlockchainButton = new Button("View Blockchain");
        buttonPane.add(voteButton, 0, 0);
        buttonPane.add(voteVerificationButton, 0, 1);
        buttonPane.add(peerBlockchainButton, 0, 2);
        buttonPane.add(resultsButton, 0, 3);
        buttonPane.add(logOutButton, 0, 4);
        logOutButton.setOnAction(e->navigator.navigateToLogin());
        voteButton.setOnAction(e->navigator.navigateToVote());
        peerBlockchainButton.setOnAction(e->{navigator.navigateToPeerBlockChain();});
        resultsButton.setOnAction(e->navigator.navigateToPeerResults());
        voteVerificationButton.setOnAction(e->navigator.navigateToVoteVerification());
        /***********************style************************ */
        this.add(buttonPane, 0, 1); // Add the button pane as a single cell
        WelcomeUI.styleButton(logOutButton);
        WelcomeUI.styleButton(resultsButton);
        WelcomeUI.styleButton(voteVerificationButton);
        WelcomeUI.styleButton(voteButton);
        WelcomeUI.styleButton(peerBlockchainButton);
        this.setStyle(
                        "-fx-background-image: url('Peer/imgs/whiteTallBuildings.jpg');" +
                        "-fx-background-size: cover;" +
                        "-fx-background-repeat: no-repeat;"
                     );
        menuLabel.setTextFill(Color.rgb(41, 137, 216));
        menuLabel.setFont(Font.font("Arial",24));
    }
}
