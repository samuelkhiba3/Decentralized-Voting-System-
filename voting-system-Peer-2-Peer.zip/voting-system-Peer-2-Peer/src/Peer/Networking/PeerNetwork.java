package Peer.Networking;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;

public class PeerNetwork {
    private Socket socket;
    private Socket broadcastSocket;
    private static Blockchain<String> blockchain;
    public PeerNetwork(){
        blockchain = new Blockchain<>();
        blockchain.registerStake("validator1", 20);
        blockchain.registerStake("validator2", 15);
        try {
            socket = new Socket("localhost",2000);
            broadcastSocket = new Socket("localhost",3000);
            PrintWriter writer = new PrintWriter(socket.getOutputStream(),true);
            writer.println("Sync blockchain");
            new Thread(()->{
                syncBlockchain();
                waitForTransactions();
            }).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void waitForTransactions(){
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(broadcastSocket.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
               if(line.equals("Broadcasting Transaction")){
                 String transactionString = reader.readLine(); 
                 System.out.println("Broadcasted transaction: "+ transactionString);
                 String sender = transactionString.split("\'\'")[0];
                 String receiver = transactionString.split("\'\'")[1];
                 String data = transactionString.split("\'\'")[2];
                 List<Transaction<String>> list = new ArrayList<>();
                 Transaction<String> transaction =new Transaction<>(sender,receiver,data);
                 list.add(transaction);
                 blockchain.addBlock(list);
               }else{
                 System.out.println("invalid response");
               }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void syncBlockchain(){
        try {
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(broadcastSocket.getInputStream()));
            String line = reader.readLine();

            if(!line.isEmpty()){
                String[] Blocks = line.split("\'\'");
                for(String blockData : Blocks){
                    // Extract the part containing sender information within transactions
                    int startIndex = blockData.indexOf("sender='") + "sender='".length();
                    int endIndex = blockData.indexOf("'", startIndex);
                    String sender = blockData.substring(startIndex, endIndex);

                    // Further processing to extract other information (receiver, data, etc.) if needed
                    // Extract receiver
                    startIndex = blockData.indexOf("receiver='") + "receiver='".length();
                    endIndex = blockData.indexOf("'", startIndex);
                    String receiver = blockData.substring(startIndex, endIndex);

                    // Extract transaction data (candidate details)
                    startIndex = blockData.indexOf("data=") + "data=".length();
                    endIndex = blockData.indexOf(", timestamp=", startIndex);
                    if (startIndex != -1 && endIndex != -1 && endIndex > startIndex) {
                        String transactionData = blockData.substring(startIndex, endIndex);
                        List<Transaction<String>> list = new ArrayList<>();
                        Transaction<String> transaction =new Transaction<>(sender,receiver,transactionData);
                        list.add(transaction);
                        blockchain.addBlock(list);    
                    }
                    
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public Socket getSocket() {
        return socket;
    }
    public static Blockchain<String> getBlockchain() {
        return blockchain;
    }
}
