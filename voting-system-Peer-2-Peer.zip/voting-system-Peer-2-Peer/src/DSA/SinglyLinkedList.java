package DSA;
import java.util.Iterator;

public class SinglyLinkedList<T> implements Iterable<T> {
    private static class Node<T>{
        private T data;
        private Node<T> next;

        public Node(T data, Node<T> next){
            this.data = data;
            this.next = next;
        }
        public void setData(T data){
            this.data =data;
        }
        public T getData(){
            return data;
        }
        public void setNext(Node<T> next){
            this.next = next;
        }
        public Node<T> getNext(){
            return next;
        }
    }
    private int size;
    private Node<T> head;
    private Node<T> tail;

    public SinglyLinkedList(){
        tail = new Node<>(null, null);
        head = new Node<>(null,tail);
        
        size=0;
    }

    public T first(){
        if(isEmpty()){
            throw new IllegalStateException("List is empty!");
        }
        return head.getNext().getData();
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void addFirst(T data){
        Node<T> newNode = new Node<>(data, head.getNext());
        head.setNext(newNode);
        size++;
    }

    public T removeFirst(){
        if(isEmpty()){
            throw new IllegalStateException("List is empty!");
        }
        return removeAfter(head);
    }

    public T removeAfter(Node<T> node ){
        Node<T> temp = node.getNext();
        T removed = temp.getData();
        node.setNext(node.getNext());
        temp.setData(null);
        temp.setNext(null);
        temp=null;
        size--;
        return removed;
    }

    public int size(){
        return size;
    }

    @Override
    public Iterator<T> iterator() {
        return new SinglyLinkedListIterator();
    }

    private class SinglyLinkedListIterator implements Iterator<T> {
        private Node<T> current = head.getNext();

        @Override
        public boolean hasNext() {
            return current != tail;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new IllegalStateException("No next element");
            }
            T data = current.getData();
            current = current.getNext();
            return data;
        }
    }
}
