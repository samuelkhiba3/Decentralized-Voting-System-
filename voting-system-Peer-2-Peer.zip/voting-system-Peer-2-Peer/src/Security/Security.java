package Security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Security {
    
    public static String hash(String password){
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(password.getBytes());
            byte[] byteArr = messageDigest.digest();
            StringBuilder builder = new StringBuilder();
            for(byte temp : byteArr){
                builder.append(String.format("%02x",temp));
            }
            return builder.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return " ";
    }
}
