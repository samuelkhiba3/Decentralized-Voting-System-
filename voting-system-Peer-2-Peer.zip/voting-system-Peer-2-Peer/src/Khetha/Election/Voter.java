package Khetha.Election;

import java.io.Serializable;

public class Voter implements Serializable{
    private String name;
    private String surname;
    private int age;
    private String gender;
    private String candidate=null;
    private String iD;
    private boolean voted;

    public Voter(){}
    
    public Voter(String name, String surname,String iD, int age, String gender,String candidate) {
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.gender = gender;
        this.candidate = candidate;

        this.iD=iD;
    }
    
    public String getiD() {
        return iD;
    }

    public void setiD(String iD) {
        this.iD = iD;
    }
    public String getName() {
        return name;
    }
    public String getSurname() {
        return surname;
    }
    public int getAge() {
        return age;
    }
    public String getGender() {
        return gender;
    }
    public void setCandidate(String candidate) {
        this.candidate = candidate;
        voted = true;
    }
    public String getCandidate() {
        return candidate;
    }
    public boolean isVoted() {
        return voted;
    }
    @Override
    public String toString() {
        return "Voter{" +
                "Name='" + name + '|' +
                " Surname='" + surname + '|' +
                " Age=" + age +
                " Gender='" + gender + '|' +
                " ID='"+iD+'|'+
                " Candidate='"+candidate+'|'+
                '}';
    }
}

