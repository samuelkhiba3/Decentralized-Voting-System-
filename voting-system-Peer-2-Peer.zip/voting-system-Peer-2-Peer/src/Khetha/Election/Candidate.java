package Khetha.Election;

public class Candidate {
    private String name;
    private String surname;
    private int age;
    private String id;
    private String gender;
    private int noOfVotes=0;

    // Constructor
    public Candidate(String name, String surname, int age,String gender, String id) {
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.id = id;
        this.gender=gender;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public int getAge() {
        return age;
    }
    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setAge(int age) {
        this.age = age;
    }
    public String getId() {
        return id;
    }
    public void increaseVotes(){
        noOfVotes=noOfVotes+1;
    }
    public int getNoOfVotes() {
        return noOfVotes;
    }

    @Override
    public String toString() {
        return ("Candidate: " + name + " " + surname+"\'"
                +"Age: " + age+"\'"
                +"Gender: "+gender+"\'"
                +"ID: " + id+"\'"
                +"Votes: "+noOfVotes+"\'");
    }
}
