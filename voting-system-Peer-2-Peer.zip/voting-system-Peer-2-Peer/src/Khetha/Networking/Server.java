package Khetha.Networking;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import DSA.SinglyLinkedList;
import Khetha.Election.Candidate;
import acsse.csc03a3.Blockchain;

public class Server {
    private static SinglyLinkedList<Socket> connectedPeers = new SinglyLinkedList<>();//list of all the peers for future broadcast of sockets
    private static VotersManager votersManager= new VotersManager(); //keep list of all registered peers/voters
    private static Blockchain<String> blockchain; //Voting independent Commision Blockchain
    private static SinglyLinkedList<Candidate> candidates = new SinglyLinkedList<>();  //list of nominated candidates

    public static SinglyLinkedList<Socket> getConnectedPeers() { 
        return connectedPeers; //retrieves the list of peers within a networks
    }
    public static void main(String[] args) {
        ServerSocket serverSocket=null;
        ServerSocket serverBroadcastSocket = null;
        connectedPeers = new SinglyLinkedList<>();
        blockchain= new Blockchain<>();
        blockchain.registerStake("Validator1", 10);
        int port = 2000; //port for request and response actions
        int broadcastPort = 3000; //Port desired only for broadcasting so there cannot be a collision
        try {
            serverSocket = new ServerSocket(port); //accepts the peer connection request
            serverBroadcastSocket = new ServerSocket(broadcastPort);
            System.out.println("Server listening on port " + port);

            //Immidiately when new peer join, is added in the connected Peer list
            while(true){
                Socket socket = serverSocket.accept();
                Socket peerSocket = serverBroadcastSocket.accept();
                connectedPeers.addFirst(peerSocket);
                System.out.println("New client connected!");
                new Thread(new clientHandling(socket)).start(); //Handling each peer in their own separate 
            }
        } catch (IOException e) {
            System.out.println("Peer disconnected");
            e.printStackTrace();
        }finally{
            try{
                if(serverSocket!=null) serverSocket.close();
            }catch(IOException e){
                System.out.println("Peer disconnected");
                e.printStackTrace();
            }
        }
    }
    //retrieves Commision blockcahin that is independent of other peer blockchains
    public static Blockchain<String> getBlockchain() {
        return blockchain;
    }

    //retrieves the list of Candidates nominated
    public static SinglyLinkedList<Candidate> getCandidates() {
        return candidates;
    }

    //retrieves voterManager within the network
    public static VotersManager getVotersManager() {
        return votersManager;
    }
}
