package Khetha.Networking;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import Khetha.Election.Candidate;
import Khetha.Election.Voter;
import Security.Security;
import acsse.csc03a3.Transaction;

public class clientHandling implements Runnable {
    private Socket voterSocket;
    private BufferedReader bReader;
    private BufferedWriter bWriter;
    private BufferedInputStream bInputStream;
    private BufferedOutputStream bOutputStream;


    public clientHandling(Socket socket) {
        voterSocket = socket;

        /***********************Setting/initialising the streams for reading and writing over the Socket**********/
        try {
            bReader = new BufferedReader(new InputStreamReader(voterSocket.getInputStream()));
            bWriter = new BufferedWriter(new OutputStreamWriter(voterSocket.getOutputStream()));
            bInputStream =new BufferedInputStream(socket.getInputStream());
            bOutputStream = new BufferedOutputStream(voterSocket.getOutputStream());

        } catch (Exception e) {
            e.printStackTrace();
        }
        /*********************************************************************************************************/
    }

    @Override
    public void run() {
        try (BufferedWriter fileWriter = new BufferedWriter(new FileWriter("src/Khetha/Data/votersData.data", true));
             BufferedReader fileReader = new BufferedReader(new FileReader("src/Khetha/Data/votersData.data"))) {
            
            //reading multiple request from the peer/voter
            String voterRequest;
            while ((voterRequest = readFromClient()) != null) {
                File voterFile = new File("src/Khetha/Data/votersData.data");
                File adminFile = new File("src/Khetha/Data/adminData.data");

                System.out.println(voterRequest);
                switch (voterRequest) {
                    case "Register": {
                        if (voterFile.exists()) {
                            String voterCredentials = readFromClient(); //Extractracting peer credintials during registration

                            //If the peer has already registred we notify that peer so they can be aware that casting a vote more than once is against our defined rules
                            if (alreadyRegistered(voterCredentials, fileReader)) {
                                writeToClient("ALREADY REGISTERED!");

                            } else { //if the voter/peer has not voted yet we allow the vote to be cast
                                String key =generateKey(); //generating random key that'll be assigned to the voter for future login
                                String privateKey = Security.hash(key); //before storing the generated peer key and storing it we hash so cannot be abused

                                fileWriter.write("\n"+privateKey + "\'" + voterCredentials); //attaching the key along with its peer or voter on the votersData record
                                fileWriter.flush();
                                System.out.println("wrote voter cred to file");
                                
                                writeToClient("LogIn Key(keep it safe!) :" + key); //Send the key to voter for safe keeping as it will be requested when logging in
                                System.out.println("Private Key generated (Hashed): " +privateKey);

                                //Voter/peer details are retrieved and the Voting Commision updates its Blockchain to indicate the current Registration transaction that has occured
                                String age =voterCredentials.split("\'")[4];
                                String gender =voterCredentials.split("\'")[5];
                                String transactionString = key+"\'\'Khetha(Vote)\'\'"+"sent registration details: "+"Age:"+age+" Gender:"+gender+" ...";
                                createTransaction(transactionString);

                            }
                        }else {
                            System.err.println("file path:" + voterFile.getPath() + "could not be found!");
                        }
                        break;
                    }
                    case "LogIn": {
                        String[] tempArray = readFromClient().split("\'"); //Login user-type is receved along with relevent login details

                        //if the first word/ element from received request was admin we lift admin priviledge action to add candidate and so on 
                        if (tempArray[0].equals("Admin")) {
                            // Validate admin login
                            validateLogin(adminFile, tempArray[1], tempArray[2]);
                        } else if (tempArray[0].equals("User")) { //else the request was from the peer/voter
                            // Validate user login
                            validateLogin(voterFile, tempArray[1], tempArray[2]);
                        }
                        break;
                    }
                    case "ADD CANDIDATE": {
                        String credentials = generateKey()+"\'"+readFromClient();
                        System.out.println("cred received");
                        addCandidate(credentials);
                        break;
                    }
                    case "Vote":{
                        // Informing the client that the server received the candidate retrieval request
                        System.out.println("Received candidate retrieval request from client.");
                        writeToClient("retrieval request received");
                    
                        // Sending the candidate data to the client
                        sendCandidateData();
                        break;
                    }
                    case "SUBMIT VOTE":{
                        handleVoteSubmission();
                        break;
                    }
                    case "Results":{
                        if(readFromClient().equals("ready")){
                            sendVotingResults(); //sending voting results to the peer/voter
                        }
                        break;
                    }
                    case "Transaction":{
                        broadCastTransaction(readFromClient()); //broadcasting all the connected peers and alerting the of new transaction so they can update their blockchain independently
                        break;
                    }
                    case "Blockchain":{
                        writeToClient(sendBlockchain()); //Output or display the Voting commision blockchain to Admin side
                        break;
                    }
                    case "Verify Blockchain":{
                        //This Verify condition is not for peer but for the Admin who'll act as commision worker to verify Voting commision blockchain
                        if(Server.getBlockchain().isChainValid()){ //if commision blockchain is valid it alerts the Admin
                            writeToClient("Valid blockchain");
                        }else{
                            writeToClient("Invalid blockchain");//otherwise notify Admin that the blockchain might have been tepered with
                        }
                        break;
                    }
                    case "Sync blockchain":{
                        syncBlockchain(); //sends or broadcast commision blockchain to newly joned peer to sync it
                        break;
                    }
                    case "Voted Candidate":{
                        sendVotedCandidate(); //sends voted candidate to the peer who has cast a vote
                        break;
                    }
                    default:{
                        System.out.println("Invalid option!");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
  
  private void sendVotedCandidate() {
       String request = null;
       if((request=readFromClient()).startsWith("KEY")){ //request contains keys and other relevent details
            System.out.println(request.split("\'")[1]);

            //During retrieval of voted candidate request by peer/voter the voter object is extracted from the voters list based on the key of the voter passed
            Voter voter= Server.getVotersManager().getVoterByPrivateKey(request.split("\'")[1]);
            System.out.println("Voter:"+voter);

            //for every store candidate we check to see if the candidate voted by the voter/peer matches with one of the candidate
            //if there is a match we extract that candidate we send the candidate details alonng with its image/profile to peer/voter
            //otherwise we notify the peer/voter to say the candidate was not found
            for(Candidate candidate: Server.getCandidates()){
                if(candidate.getId().equals(voter.getCandidate())){
                    try{
                        File candidateDataFile = new File("src/Khetha/Data/candidateData.data");
                        BufferedReader fileReader = new BufferedReader(new FileReader(candidateDataFile));
                        String line;
                        while((line=fileReader.readLine())!=null){
                            if(line.split("\'")[0].equals(candidate.getId())){
                                String profileName = line.split("\'")[5];
                                File file =new File("src/Khetha/imgs/"+profileName);
                                long fileSize = file.length();
                                System.out.println("Candidate: "+candidate);
                                writeToClient("CANDIDATE DETAILS\'"+candidate.getName()+"\'"+candidate.getSurname()+"\'"+candidate.getAge()+"\'"+candidate.getId()+"\'"+fileSize+"\'"+profileName);
                                if(readFromClient().equals("SEND PROFILE")){
                                    BufferedInputStream fileInputStream = new BufferedInputStream(new FileInputStream(file));
                                    byte[] buffer = new byte[1024];
                                    int read;
                                    long totalBytesRead = 0;
                                    while((totalBytesRead<fileSize)&&(read = fileInputStream.read(buffer)) != -1){
                                        bOutputStream.write(buffer, 0, read);
                                        totalBytesRead+=read;
                                        bOutputStream.flush();
                                    }
                                    fileInputStream.close();
                                }
                                return;
                            }
                        } 
                        fileReader.close();       
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }
            writeToClient("Not Found");
        }
    }


private void syncBlockchain(){
    StringBuilder builder = new StringBuilder();
    try {
        Socket recentPeerSocket = Server.getConnectedPeers().first(); //The newly joined peer is at the first node so use fist mehod to access the peer socket
        PrintWriter writer = new PrintWriter(recentPeerSocket.getOutputStream(),true); //set and initialize relevent writer stream for response
        String blocks[] = Server.getBlockchain().toString().split("\n");
        for(int i=1 ; i<blocks.length;i++){
            builder.append(blocks[i]+"\'\'");
        }
        writer.println(builder.toString()); //broadcast all the blocks of the Commision blockchain
    } catch (IOException e) {
        e.printStackTrace();
    }
  }

  //sends blockchain to Admin for viewing not to peer/voter
  private String sendBlockchain(){
    StringBuilder builder = new StringBuilder();
    String[] blocks = Server.getBlockchain().toString().split("\n");
    for(String string : blocks){
        builder.append(string+"\'\'");
    }
    return builder.toString();
  }

  //responsible to create a transaction 
  private void createTransaction(String string){
    String sender = string.split("\'\'")[0];
    String receiver = string.split("\'\'")[1];
    String data = string.split("\'\'")[2];
    String transactionString = sender+"\'\'"+receiver+"\'\'"+data;
    List<Transaction<String>> list = new ArrayList<>();
    Transaction<String> transaction =new Transaction<>(sender,receiver,data);
    list.add(transaction);
    Server.getBlockchain().addBlock(list);
    broadCastTransaction(transactionString);
  }

  //brodcasts the created transaction to all peers registred
  private void broadCastTransaction(String string){
      try{
        for(Socket socket : Server.getConnectedPeers()){
            PrintWriter writer = new PrintWriter(socket.getOutputStream(),true);
            writer.println("Broadcasting Transaction");
            writer.println(string);
        }
      }catch (Exception e) {
        e.printStackTrace();
      } 
  }

  //sends results to the peer/voter registered
  private void sendVotingResults() {
       StringBuilder builder = new StringBuilder();
       for(Candidate candidate:Server.getCandidates()){
            builder.append("'"+candidate);
       }
       if(!builder.isEmpty()){
            writeToClient("ready");
            System.out.println(builder);
            writeToClient(builder.toString());
       }else{
            writeToClient("Not ready");
       }
    }

  private boolean voted(Voter voter){
    return voter.isVoted();
  }

  private void handleVoteSubmission() throws IOException {
        String key = readFromClient();
        Voter voter = Server.getVotersManager().getVoterByPrivateKey(key);
        if(voted(voter)){
            writeToClient("ALREADY VOTED");
        }else{
            String candidateId = readFromClient();
            Candidate candidateChosen = findCandidateById(candidateId);
            voter.setCandidate(candidateId);
            candidateChosen.increaseVotes();
            writeToClient("SENDING VOTER DETAILS");
            sendVoterDetails(voter);
            String transaction = readFromClient();
            createTransaction(transaction);
        }
    }
    private Candidate findCandidateById(String id){
        Candidate tempCandidate=null;
        for(Candidate candidate: Server.getCandidates()){
            if(candidate.getId().equals(id)){
                tempCandidate=candidate;
                break;
            }
        }
        return tempCandidate;
    }
    private void sendVoterDetails(Voter voter) throws IOException {
        System.out.println(voter);
        ObjectOutputStream objOutStream = new ObjectOutputStream(voterSocket.getOutputStream());
        objOutStream.writeObject(voter);
        objOutStream.flush();
        System.out.println("Sent voter details to client.");
    }

    private void updateVotingDate(String dateString) {
        File votingDateFile = new File("src/Khetha/Data/votingDate.data");
    
        try (BufferedWriter dateWriter = new BufferedWriter(new FileWriter(votingDateFile))) {
            // Write the new date string to the voting date file
            dateWriter.write(dateString);
            dateWriter.newLine();
            dateWriter.flush();
    
            writeToClient("Voting date updated successfully to: " + dateString);
        } catch (IOException e) {
            e.printStackTrace();
            writeToClient("Failed to update voting date.");
        }
    }
    
    private void sendCandidateData(){
        File candidateDataFile = new File("src/Khetha/Data/candidateData.data");
        try(BufferedReader fileReader = new BufferedReader(new FileReader(candidateDataFile))){
            String line;
            if(readFromClient().equals("send data")){
                while((line=fileReader.readLine())!=null){
                        // Sending candidate data to the client
                        System.out.println("Sending candidate data: " + line);
                        writeToClient(line);
                        String id = line.split("\'")[0];
                        String name = line.split("\'")[1];
                        String surname= line.split("\'")[2];
                        int age = Integer.parseInt(line.split("\'")[3]);
                        String gender = line.split("\'")[4];
                        boolean contained = false;
                        if(Server.getCandidates().isEmpty()){
                            Server.getCandidates().addFirst(new Candidate(name, surname, age, gender, id));
                        }else{
                            for(Candidate candidate: Server.getCandidates()){
                                if(candidate.getId().equals(id)){
                                    contained=true;
                                }
                            }
                            if(!contained){
                                Server.getCandidates().addFirst(new Candidate(name, surname, age, gender, id));
                            }
                        }
                        // Sending candidate image to the client
                        String profileName = line.split("\'")[5];
                        if(readFromClient().contains("send profile")){
                            sendCandidateImage(profileName);
                        }
                }
                writeToClient("Candidate data sent");
            }
            
        } catch(Exception e){
            e.printStackTrace();
        }
    }
    
    private void sendCandidateImage(String profileName){
        try {
            // Sending candidate image to the client
            if(readFromClient().equals("cached")){
                System.out.println("Image already cached on client side");
            }else{
                System.out.println("Sending candidate image: " + profileName);
                File file =new File("src/Khetha/imgs/"+profileName);
                long fileSize = file.length();
                BufferedInputStream fileInputStream = new BufferedInputStream(new FileInputStream(file));
                byte[] buffer = new byte[1024];
                int read;
                long totalBytesRead = 0;
                while((totalBytesRead<fileSize)&&(read = fileInputStream.read(buffer)) != -1){
                    bOutputStream.write(buffer, 0, read);
                    totalBytesRead+=read;
                }
                bOutputStream.flush();
                fileInputStream.close();
                System.out.println("Candidate image sent: " + profileName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addCandidate(String credentials){
        String[] tempArray =credentials.split("\'");
        String id = tempArray[0];
        String name = tempArray[1];
        String surname = tempArray[2];
        int age = Integer.parseInt(tempArray[3]);
        String fileName = tempArray[5];
        long fileSize =Long.parseLong(tempArray[6]);
        long totalBytesRead = 0;
        System.out.println("fileName: "+fileName + "fileSize: "+fileSize);
        createTransaction("Admin\'\'Khetha(Voter)\'\'"+"Candidate added to Khetha Platform Name:"+name+" Surname:"+surname+" Id:"+id+" Age:"+age);
        writeToClient("credentials received");
        System.out.println("cred received respond sent");
        try(FileOutputStream fileOutputStream = new FileOutputStream("src/Khetha/imgs/"+fileName);
            BufferedWriter fileWriter = new BufferedWriter(new FileWriter("src/Khetha/Data/candidateData.data",true))) {
            byte[] buffer = new byte[1024];
            int read;
            while((totalBytesRead<fileSize) && (read=bInputStream.read(buffer))!=-1){
                fileOutputStream.write(buffer, 0, read);
                totalBytesRead +=read;
            }
            fileWriter.write(credentials+"\n");
            fileWriter.flush();
            System.out.println("file received");
            fileOutputStream.flush();
            writeToClient("done");
            System.out.println("done resp sent");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String readFromClient() {
        String response = null;
        try {
            response = bReader.readLine();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    private void writeToClient(String string) {
        try {
            bWriter.write(string);
            bWriter.newLine();
            bWriter.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String generateKey() {
        SecureRandom secureRandom = new SecureRandom();
        byte[] keyBytes = new byte[5];
        secureRandom.nextBytes(keyBytes);
        BigInteger keyInt = new BigInteger(1, keyBytes);
        String generatedKey = keyInt.toString(16);
        while (generatedKey.length() < 10) {
            generatedKey = "0" + generatedKey;
        }
        return generatedKey;
    }

    // Checking if the voter is already registered
    private boolean alreadyRegistered(String credentials, BufferedReader fileReader) {
        boolean alreadyExist = false;
        try {
            String iD = credentials.split("\'")[3];
            String temp = null;
            while ((temp = fileReader.readLine()) != null) {
                if (temp.split("\'")[4].equals(iD)) {
                    alreadyExist = true;
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return alreadyExist;
    }

    private void validateLogin(File file, String key, String password) {
        try (BufferedReader bReader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = bReader.readLine()) != null) {
                // Check if the line contains both the key and the password
                if (line.contains(Security.hash(key)) && line.contains(Security.hash(password))) {
                    if(line.startsWith("ADMIN:")){
                        writeToClient("true");
                    }else{
                        String[] arr = line.split("\'");
                        String name = arr[2];
                        String surname = arr[3];
                        String iD = arr[4];
                        int age = Integer.parseInt(arr[5]);
                        String gender = arr[6];
                        String candidate= arr[7];
                        Voter voter = new Voter(name, surname, iD, age, gender,candidate);
                        Server.getVotersManager().addVoter(key, voter);
                        writeToClient("true"); // Login successful
                    }
                    return;
                }
            }
            writeToClient("false"); // Login failed
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
