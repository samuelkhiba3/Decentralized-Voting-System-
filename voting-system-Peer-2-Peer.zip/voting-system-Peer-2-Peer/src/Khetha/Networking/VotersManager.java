package Khetha.Networking;

import java.util.HashMap;
import java.util.Map;

import Khetha.Election.Voter;

public class VotersManager {
    private Map<String, Voter> votersMap = new HashMap<>();

    public void addVoter(String key, Voter voter){
        if(!votersMap.containsKey(key)){
            votersMap.put(key, voter);
        }
    }
    public Voter getVoterByPrivateKey(String key) {
        return votersMap.get(key);
    }

}