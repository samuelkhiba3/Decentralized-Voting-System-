import Peer.UI.Navigator;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class MainApp extends Application {
    @SuppressWarnings("unused")
    private Stage primaryStage;
    private Navigator navigator;

    @Override
    public void start(Stage primaryStage) {
        Image iconImage = new Image(getClass().getResourceAsStream("Peer/imgs/Khetha.png"));
        // Set the application icon
        primaryStage.getIcons().add(iconImage);
        this.primaryStage = primaryStage;
        this.navigator = new Navigator(primaryStage);
        // Starts with the Welcome view
        navigator.navigateToWelcome();
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
